﻿using Microsoft.AspNetCore.Mvc;

namespace Icx_Ecm.Controllers
{
    public class SettingsController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        // Loads the Repository view
        public PartialViewResult Repository()
        {
            return PartialView("Repository"); // Returns the Repository.cshtml view
        }

        // Loads the Object view
        public PartialViewResult ObjectType()
        {
            return PartialView("ObjectType"); // Returns the Object.cshtml view
        }
    }
}
